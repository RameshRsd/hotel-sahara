

<?php $__env->startSection('content'); ?>

    <div class="main_container">
        <div class="right_col" role="main">
            <div class="content-sec">
                <div class="col-md-12">
                    <?php if(session('success')): ?>
                        <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Customer Status</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <form action="" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-sm-2">
                                        <label for="">Date Duration : From</label>
                                    </div>
                                    <div class="col-sm-2">
                                        <label for="">To</label>
                                    </div>
                                    <div style="clear: both;"></div>
                                    <div class="col-sm-2">
                                            <input type="date" name="date1" class="form-control input-sm" value="<?php echo e(request('date1')); ?>">
                                    </div>
                                    <div class="col-sm-2">
                                        <input type="date" name="date2" class="form-control input-sm" value="<?php echo e(request('date2')); ?>">
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="name" id="" class="form-control input-sm">
                                            <option value="">[Select Guest]</option>
                                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(request('name') == $Value->id): ?>
                                                <option value="<?php echo e($Value->id); ?>" selected="selected"><?php echo e($Value->name); ?> (<?php echo e($Value->contact_1); ?>)</option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($Value->id); ?>"><?php echo e($Value->name); ?> (<?php echo e($Value->contact_1); ?>)</option>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-sm-2">
                                        <select name="room_id" id="" class="form-control input-sm">
                                            <option value="">[Select Room]</option>
                                            <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(request('room_id') == $Value->id): ?>
                                                <option value="<?php echo e($Value->id); ?>" selected="selected" ><?php echo e($Value->room_no); ?></option>
                                                <?php else: ?>
                                                    <option value="<?php echo e($Value->id); ?>"><?php echo e($Value->room_no); ?></option>
                                                    <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    
                                    
                                        
                                    
                                    
                                        
                                    
                                    <div class="clearfix"></div>
                                    <div class="col-sm-2">
                                        <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff; width: 100%;">Search</button>
                                    </div>
                                </form>
                            </div>
                            <div class="x_content">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(request('name') == $Value->id): ?>
                                                Mr./Mrs. <b><?php echo e($Value->name); ?></b> Record, Phone: <?php echo e($Value->contact_1); ?><br>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $Value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(request('room_id') == $Value->id): ?>
                                                Room No. :<?php echo e($Value->room_no); ?><br>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(request('date1') && !request('date2')): ?>
                                                Dated on : <b><?php echo e(request('date1')); ?></b><br>
                                                <?php endif; ?>
                                            <?php if(request('date1') && request('date2')): ?>
                                                From : <b><?php echo e(request('date1')); ?></b> to <b><?php echo e(request('date2')); ?></b><br>
                                                <?php endif; ?>
                                        Total : <i style="color:Green; font-weight: bolder;"><?php echo e(count($roomCheck)); ?></i> Record Found !
                                        <tr>
                                            <th>SN</th>
                                            <th>Date</th>
                                            <th>Guest Name</th>
                                            <th>Phone</th>
                                            <th>Customer ID</th>
                                            <th>Regd No.</th>
                                            <th>Room</th>
                                            <th>in time</th>
                                            <th>Male</th>
                                            <th>Female</th>
                                            <th>Relation</th>
                                            <th>Purpose</th>
                                            <th>Remarks</th>
                                            <th>Billing</th>
                                            <th>Entry by</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php if(count($roomCheck)>0): ?>
                                        <?php $__currentLoopData = $roomCheck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomSts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td><?php echo e($roomSts->date); ?></td>
                                                    <td>
                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                <?php echo e($customerValue->name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                <?php echo e($customerValue->contact_1); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                <?php echo e($customerValue->customer_id_no); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td><?php echo e($roomSts->customer_id); ?></td>
                                                    <td>
                                                        <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($room->id == $roomSts->room_id): ?>
                                                                <a href="" style="color:#000; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td><?php echo e($roomSts->time); ?></td>
                                                    <td><?php echo e($roomSts->male); ?></td>
                                                    <td><?php echo e($roomSts->female); ?></td>
                                                    <td><?php echo e($roomSts->relation); ?></td>
                                                    <td><?php echo e($roomSts->purpose); ?></td>
                                                    <td></td>
                                                    <td>
                                                        <a href="<?php echo e(url('roomCheck/'.$roomSts->id.'/editBill')); ?>" class="btn btn-info btn-xs">View</a>
                                                    </td>
                                                    <div class="modal fade" id="guest_biiling" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                                                        <div class="modal-dialog modal-sm" role="document">
                                                            <div class="modal-content" style="width: 500px; margin:0 auto;">
                                                                <div class="modal-header">
                                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                                    <h4 class="center title_red" id="myModalLabel">Customer Details</h4>
                                                                </div>
                                                                <div class="modal-body center">

                                                                    <div class="col-sm-7 col-md-7 col-xs-12">
                                                                        <form action="<?php echo e(url('roomCheck/'.$roomSts->id.'/updateBill')); ?>" method="post">
                                                                            <?php echo e(csrf_field()); ?>

                                                                            <h5>Transaction Date: <?php echo e($roomSts->date); ?></h5>
                                                                            <label for="">Total Transaction</label>
                                                                            <input type="text" class="form-control" name="total_transaction" value="<?php echo e($roomSts->total_transaction); ?>" placeholder="Total Bill">
                                                                            <div style="margin:10px 0;"></div>
                                                                            <label for="">Paid</label>
                                                                            <input type="text" class="form-control" name="guest_paid" value="<?php echo e($roomSts->guest_paid); ?>" placeholder="Paid">
                                                                            <div style="margin:10px 0;"></div>
                                                                            <label for="">Due</label>
                                                                            <input type="text" class="form-control" name="guest_due" value="<?php echo e($roomSts->guest_due); ?>" placeholder="Due">
                                                                            <div style="margin:10px 0;"></div>
                                                                            <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Update</button>
                                                                        </form>
                                                                    </div>
                                                                    <div class="col-sm-5 col-md-5 col-xs-12" style=" text-align: center;">
                                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                        <img src="<?php echo e(url('public/images/Customer/'.$customerValue->photo)); ?>" alt="image not found" width="100">
                                                                                <br><br><b><?php echo e($customerValue->name); ?></b><br>(<i><?php echo e($customerValue->contact_1); ?></i>)
                                                                                <p>

                                                                                    <?php $__currentLoopData = $locationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($location->id == $customerValue->location_id): ?>
                                                                                            <?php echo e($location->name); ?>-<?php echo e($customerValue->ward_no); ?>, <?php echo e($customerValue->tole); ?><br>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php $__currentLoopData = $districtData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($district->id == $customerValue->district_id): ?>
                                                                                            <?php echo e($district->name); ?>,
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php $__currentLoopData = $zoneData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($zone->id == $customerValue->zone_id): ?>
                                                                                            <?php echo e($zone->name); ?> Zone<br>
                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php $__currentLoopData = $countryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                        <?php if($country->id == $customerValue->country_id): ?>
                                                                                            <?php echo e($country->country_name); ?>

                                                                                        <?php endif; ?>
                                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                                </p>
                                                                                <i><?php echo e($customerValue->id_type); ?> (ID No.): <?php echo e($customerValue->customer_id_no); ?></i>
                                                                        <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </div>
                                                                    <div class="clear"></div>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <td>
                                                        <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($user->id == $roomSts->user_id): ?>
                                                                <?php echo e($user->name); ?> (<?php echo e($user->user_type); ?>)
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </td>
                                                    <td>
                                                        <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($room->id == $roomSts->room_id && $room->room_status == 'CheckedIn' && $room->date == $roomSts->date && $room->customer_id == $roomSts->customer_id): ?>
                                                                <form action="<?php echo e(url('admin/'.$roomSts->room_id.'/updateRoomSts')); ?>" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" name="room_status" value="CheckedOut">
                                                                    <input type="hidden" name="date" value="">
                                                                    <button type="submit" class="btn btn-success btn-xs">Checked Out</button>
                                                                </form>
                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($roomSts->date == date('Y-m-d')): ?>
                                                            <?php else: ?>
                                                        <form action="<?php echo e(url('admin/'.$roomSts->room_id.'/updateRoomCheck')); ?>" method="post">
                                                            <?php echo e(csrf_field()); ?>

                                                            <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                                            <input type="hidden" name="date" value="<?php echo date('Y-m-d') ?>">
                                                            <input type="hidden" name="room_status" value="CheckedIn">
                                                            <input type="hidden" name="room_id" value="<?php echo e($roomSts->room_id); ?>">

                                                            <input type="hidden" name="customer_id" value="<?php echo e($roomSts->customer_id); ?>">
                                                            <input type="hidden" name="male" value="<?php echo e($roomSts->male); ?>">
                                                            <input type="hidden" name="female" value="<?php echo e($roomSts->female); ?>">
                                                            <input type="hidden" name="relation" value="<?php echo e($roomSts->relation); ?>">
                                                            <input type="hidden" name="purpose" value="<?php echo e($roomSts->purpose); ?>">
                                                            <input type="hidden" name="remarks" value="<?php echo e($roomSts->remarks); ?>">

                                                            <button type="submit" class="btn btn-warning btn-xs">Continue</button>
                                                        </form>
                                                                <?php endif; ?>
                                                    </td>
                                                </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                        <tr>
                                            <td colspan="16"><a class="btn btn-danger btn-xs">Record Not Found</a></td>
                                        </tr>
                                            <?php endif; ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>