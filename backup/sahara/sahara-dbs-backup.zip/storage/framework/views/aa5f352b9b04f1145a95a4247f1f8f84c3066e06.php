<?php $__env->startSection('content'); ?>
    <?php if(Auth::user()->user_status =='1'): ?>
        <?php $__currentLoopData = $server; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codeData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($codeData->name < date('Y-m-d')): ?>
                <div class="main_container">
                    <div class="right_col" role="main">
                        <div class="content-sec">
                            <div class="col-md-12">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <?php if(session('success')): ?>
                                        <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                                    <?php endif; ?>
                                    <?php if($errors->any()): ?>
                                        <ul  class="alert alert-danger">
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    <?php endif; ?>
                                    <div class="x_panel">
                                        <a class="btn btn-danger btn-xs">Your Software Was Expired ! </a>
                                        <p style="color:#3c763d;">Please Contact us for Renew<br>
                                            <a href="http://geniusservicenepal.com/" style="color:Blue;">Genius Service Nepal Pvt. Ltd.</a>
                                        <br>
                                            Putalisadak, Kathmandu, Nepal<br>
                                        Phone : 01-4011099, 9856065444<br>
                                        Email : geniusservicenepal@gmail.com || youramesh5@gmail.com
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="main_container">
                    <div class="right_col" role="main">
                        <div class="content-sec">
                            <div class="col-md-12">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <?php if(session('success')): ?>
                                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                                        <?php endif; ?>
                                        <?php if($errors->any()): ?>
                                            <ul  class="alert alert-danger">
                                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li><?php echo e($error); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                        <div class="x_panel">
                                            <div class="x_title">
                                                <i style="float: right;"><a href="<?php echo e(route('roomView')); ?>" style="margin:0; padding:2px; background-color: grey; color:#fff;" class="btn btn-xs" >View All</a></i>
                                                <i style="float: right; margin:0 5px;"><a href="" style="margin:0; padding:2px; background-color: grey; color:#fff;" class="btn btn-xs"  data-toggle="modal" data-target="#room_modal">Add Rooms</a></i>
                                                <i style="float: right; margin:0 5px;"><a href="" style="margin:0; padding:2px; background-color: grey; color:#fff;" class="btn btn-xs"  data-toggle="modal" data-target="#floor_modal">Add Room Floor</a></i>
                                                <i style="float: right;"><a href="" style="margin:0; padding:2px; background-color: grey; color:#fff;" class="btn btn-xs"  data-toggle="modal" data-target="#roomType_modal">Add Room Type</a></i>

                                                <h2>Room Status</h2>
                                                <ul class="nav navbar-right panel_toolbox">
                                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                                    </li>

                                                    <li class="dropdown">
                                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                                        <ul class="dropdown-menu" role="menu">
                                                            <li><a href="#">Settings 1</a>
                                                            </li>
                                                            <li><a href="#">Settings 2</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                                    </li>
                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="x_content" style="padding:0; margin:0;">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <h5 style="text-align: center; color:Green; font-weight: bolder;">Today Room Status
                                                        <span style="color:#1ea094;">
                                                    <script type="text/javascript">
                                                        var tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

                                                        function GetClock(){
                                                            var d=new Date();
                                                            var nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getFullYear();

                                                            var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

                                                            if(nhour==0){ap=" AM";nhour=12;}
                                                            else if(nhour<12){ap=" AM";}
                                                            else if(nhour==12){ap=" PM";}
                                                            else if(nhour>12){ap=" PM";nhour-=12;}

                                                            if(nmin<=9) nmin="0"+nmin;
                                                            if(nsec<=9) nsec="0"+nsec;

                                                            document.getElementById('clockbox').innerHTML=""+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
                                                        }

                                                        window.onload=function(){
                                                            GetClock();
                                                            setInterval(GetClock,1000);
                                                        }
                                                    </script>
                                                    <div id="clockbox"></div>
                                                    </span>
                                                    </h5>
                                                    <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                                        <tr>
                                                            <th style="text-align: center; background-color: grey; color:#fff; padding:5px;">Floor</th>
                                                            <th style="text-align: center; background-color: grey; color:#fff; padding:5px;" colspan="10">Room</th>
                                                        </tr>

                                                        <?php $__currentLoopData = $FloorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <tr>
                                                            <td style="background-color: #7b4b71; color:#fff; padding:5px;"><?php echo e($floor->name); ?></td>
                                                            <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $RoomTYpeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if($floor->id == $room->floor_id && $room->room_type_id == $roomType->id): ?>
                                                                    <?php if($room->room_status == 'CheckedOut'): ?>
                                                                    <td>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <a href="<?php echo e(url('admin/'.$room->id.'/RoomStatus')); ?>" style="background-color: Green; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <i style="background-color: grey; color:#fff; padding:5px;"><?php echo e($roomType->name); ?></i>
                                                                        </div>
                                                                    </td>
                                                                    <?php elseif($room->room_status == 'CheckedIn'): ?>
                                                                    <td>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                        <a href="" style="background-color: Red; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                        <i style="background-color: grey; color:#fff; padding:5px;"><?php echo e($roomType->name); ?></i>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($room->customer_id == $customerData->id): ?>
                                                                                <a href="<?php echo e(route('roomCheck')); ?>" style="color:#fff; background-color: Red;" class="btn btn-xs">Sold : <?php echo e($customerData->name); ?></a>
                                                                            <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    </td>
                                                                            <?php else: ?>
                                                                    <td>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                        <a href="<?php echo e(url('admin/'.$room->id.'/RoomStatus')); ?>" style="background-color: Orange; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <i style="background-color: grey; color:#fff; padding:5px;"><?php echo e($roomType->name); ?></i>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                        <?php $__currentLoopData = $booked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($room->id == $bookData->room_id): ?>
                                                                                <a href="<?php echo e(route('roomBook')); ?>" style="color:#fff;" class="btn btn-warning btn-xs">Booked : <?php echo e($bookData->customer_name); ?></a>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    </td>
                                                                    <?php endif; ?>
                                                                <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </table>
                                                </div>
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <hr>
                                                    <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                                        <tr>
                                                            <th style="width:25px; height: 25px; background-color: Orange;"></th>
                                                            <th style="color:Orange;">Booked (Pending)</th>
                                                            <th style="width:25px; height: 25px; background-color: Red;"></th>
                                                            <th style="color:Red;">Checked In (Sold)</th>
                                                            <th style="width:25px; height: 25px; background-color: Green;"></th>
                                                            <th style="color:Green;">Checked Out (Avialable)</th>
                                                        </tr>
                                                        
                                                            
                                                            
                                                        
                                                        
                                                            
                                                            
                                                        
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <div class="x_panel">
                                            <div class="x_title">
                                                <h2>Customer Status</h2>
                                                <ul class="nav navbar-right panel_toolbox">
                                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                                    </li>

                                                    <li class="dropdown">
                                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                                        <ul class="dropdown-menu" role="menu">
                                                            <li><a href="#">Settings 1</a>
                                                            </li>
                                                            <li><a href="#">Settings 2</a>
                                                            </li>
                                                        </ul>
                                                    </li>
                                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                                    </li>
                                                </ul>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="x_content">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <h5 style="text-align: center; color:Green; font-weight: bolder;">Today Guest Status (Checked In)
                                                    </h5>
                                                    <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                                        <tr>
                                                            <th>Date</th>
                                                            <th>Regd No.</th>
                                                            <th>Room</th>
                                                            <th>Guest Name</th>
                                                            <th>Address</th>
                                                            <th>Phone</th>
                                                            <th>Male</th>
                                                            <th>Female</th>
                                                            <th>Relation</th>
                                                            <th>Entry by</th>
                                                            <th>Billing</th>
                                                            <th>Action</th>
                                                        </tr>
                                                        <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomStsCheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $roomCheck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomSts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if(($roomSts->date === date('Y-m-d')) && $roomStsCheck->date === date('Y-m-d') && $roomStsCheck->id == $roomSts->room_id && $roomStsCheck->room_status == 'CheckedIn' && $roomStsCheck->customer_id == $roomSts->customer_id): ?>
                                                        <tr>
                                                            <td><?php echo e($roomSts->date); ?></td>
                                                            <td>
                                                                        <?php echo e($roomSts->customer_id); ?>

                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($room->id == $roomSts->room_id): ?>
                                                                        <a href="" style="background-color: Red; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                        <?php echo e($customerValue->name); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $districtValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($customerValue->district_id == $districtValue->id && $customerValue->id == $roomSts->customer_id): ?>
                                                                        <?php echo e($districtValue->name); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                        <?php echo e($customerValue->contact_1); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td><?php echo e($roomSts->male); ?></td>
                                                            <td><?php echo e($roomSts->female); ?></td>
                                                            <td><?php echo e($roomSts->relation); ?></td>
                                                            <td>
                                                                <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($user->id == $roomSts->user_id): ?>
                                                                        <?php echo e($user->name); ?> (<?php echo e($user->user_type); ?>)
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <a href="<?php echo e(url('roomCheck/'.$roomSts->id.'/editBill')); ?>" class="btn btn-info btn-xs">View</a>
                                                            </td>
                                                            <td>
                                                                <form action="<?php echo e(url('admin/'.$roomSts->room_id.'/updateRoomSts')); ?>" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" name="room_status" value="CheckedOut">
                                                                    <input type="hidden" name="date" value="">
                                                                    <button type="submit" class="btn btn-success btn-xs">Checked Out</button>
                                                                </form>
                                                                <?php if($roomSts->date == date('Y-m-d')): ?>
                                                                    <?php else: ?>
                                                                <form action="<?php echo e(url('admin/'.$roomSts->room_id.'/updateRoomCheck')); ?>" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                                                    <input type="hidden" name="date" value="<?php echo date('Y-m-d') ?>">
                                                                    <input type="hidden" name="room_status" value="CheckedIn">
                                                                    <input type="hidden" name="room_id" value="<?php echo e($roomSts->room_id); ?>">

                                                                    <input type="hidden" name="customer_id" value="<?php echo e($roomSts->customer_id); ?>">
                                                                    <input type="hidden" name="time">
                                                                    <input type="hidden" name="male" value="<?php echo e($roomSts->male); ?>">
                                                                    <input type="hidden" name="female" value="<?php echo e($roomSts->female); ?>">
                                                                    <input type="hidden" name="relation" value="<?php echo e($roomSts->relation); ?>">
                                                                    <input type="hidden" name="purpose" value="<?php echo e($roomSts->purpose); ?>">
                                                                    <input type="hidden" name="remarks" value="<?php echo e($roomSts->remarks); ?>">

                                                                    <button type="submit" class="btn btn-warning btn-xs">Continue</button>
                                                                    <?php endif; ?>
                                                                </form>
                                                            </td>
                                                        </tr>
                                                            <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </table>
                                                </div>
                                            </div>
                                            <div class="x_content">
                                                <div class="col-md-12 col-sm-12 col-xs-12">
                                                    <h5 style="text-align: center; color:Green; font-weight: bolder;">Today Guest Status (Booked In)
                                                    </h5>
                                                    <table class="table-condensed table-bordered table-hover" style="width: 100%;">
                                                        <tr>
                                                            <th>Name</th>
                                                            <th>Contact</th>
                                                            <th>Date</th>
                                                            <th>No. of People</th>
                                                            <th>Arrival time</th>
                                                            <th>Booked Room</th>
                                                            <th>Enter by</th>
                                                            <th>Action</th>
                                                        </tr>
                                                            <?php $__currentLoopData = $booked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomSts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(($roomSts->date === date('Y-m-d')) && $room->date === date('Y-m-d') && $room->room_id == $roomSts->id && $roomSts->room_status == 'Booked'): ?>
                                                                <tr>
                                                                    <td><?php echo e($room->customer_name); ?></td>
                                                                    <td><?php echo e($room->phone); ?></td>
                                                                    <td><?php echo e($room->date); ?></td>
                                                                    <td><?php echo e($room->people); ?></td>
                                                                    <td><?php echo e($room->time); ?></td>
                                                                    <td>
                                                                        <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                                            <?php if($value->id == $room->room_id && $value->room_status == 'Booked'): ?>
                                                                                <a style="background-color: Orange; color:#fff; padding:5px;"><?php echo e($value->room_no); ?> <i>(Still Booked)</i></a>
                                                                            <?php endif; ?>
                                                                            <?php if($value->id == $room->room_id && $value->room_status == 'CheckedIn'): ?>
                                                                                <a style="background-color: Red; color:#fff; padding:5px;"><?php echo e($value->room_no); ?> <i>(Checked In)</i></a>
                                                                            <?php endif; ?>
                                                                            <?php if($value->id == $room->room_id && $value->room_status == 'CheckedOut'): ?>
                                                                                <a style="background-color: Green; color:#fff; padding:5px;"><?php echo e($value->room_no); ?> <i>(Room Left)</i></a>
                                                                            <?php endif; ?>

                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </td>
                                                                    <td>
                                                                        <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($user->id == $room->user_id): ?>
                                                                                <?php echo e($user->name); ?> (<?php echo e($user->user_type); ?>)
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </td>
                                                                    <td style="padding:0;">
                                                                        <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                            <?php if($value->id == $room->room_id && $value->room_status == 'Booked'): ?>
                                                                                <form action="<?php echo e(url('roomBook/delete/'.$room->room_id)); ?>" method="post">
                                                                                    <?php echo e(csrf_field()); ?>

                                                                                    <input type="hidden" name="room_status" value="CheckedOut">
                                                                                    <input type="hidden" name="date" value="">
                                                                                    <button type="submit" onclick="return confirm('Are you sure you want to Unbook this room?');" class="btn btn-danger btn-xs">UnBook</button>
                                                                                </form>
                                                                            <?php elseif($value->id == $room->room_id && $value->room_status == 'CheckedOut'): ?>
                                                                                <form action="<?php echo e(url('roomBook/delete/'.$room->room_id)); ?>" method="post">
                                                                                    <?php echo e(csrf_field()); ?>

                                                                                    <input type="hidden" name="room_status" value="Booked">
                                                                                    <input type="hidden" name="date" value="">
                                                                                    <button type="submit" onclick="return confirm('Are you sure you want to Book this room?');" class="btn btn-success btn-xs">Book</button>
                                                                                </form>
                                                                                <a href="<?php echo e(url('roomBook/deleteItm/'.$room->id)); ?>" class="btn btn-danger btn-xs">Delete</a>
                                                                            <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                    </td>
                                                                </tr>
                                                                <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </table>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="room_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="center title_red" id="myModalLabel">Add Room</h4>
                            </div>
                            <?php if(session('success')): ?>
                                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <ul  class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <div class="modal-body center">
                                <form action="<?php echo e(route('addRoom')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <select class="form-control" id="floor_id" name="floor_id">
                                        <option value="">Select Floor</option>
                                        <?php $__currentLoopData = $FloorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($floor->id); ?>"><?php echo e($floor->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                        <input type="number" class="form-control" name="room_no" placeholder="Enter Room No.">
                                    <select class="form-control" id="room_type_id" name="room_type_id">
                                        <option value="">Select Room Type</option>
                                        <?php $__currentLoopData = $RoomTYpeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($roomType->id); ?>"><?php echo e($roomType->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="floor_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="center title_red" id="myModalLabel">Add Room Floor</h4>
                            </div>
                            <div class="modal-body center">
                                <form action="<?php echo e(route('addRoomFloor')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                        <input type="text" class="form-control" name="name" placeholder="Create Floor Name">
                                    <select class="form-control">
                                        <option value="">Check Floor Exist or Not</option>
                                        <?php $__currentLoopData = $FloorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($roomType->id); ?>"><?php echo e($roomType->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal fade" id="roomType_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
                    <div class="modal-dialog modal-sm" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                <h4 class="center title_red" id="myModalLabel">Add Room Type</h4>
                            </div>
                            <?php if(session('success')): ?>
                                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <ul  class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <div class="modal-body center">
                                <form action="<?php echo e(route('addRoomType')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>

                                        <input type="text" class="form-control" name="name" placeholder="Create Room Type">
                                    <select class="form-control">
                                        <option value="">Check Exist Room Type or Not</option>
                                        <?php $__currentLoopData = $RoomTYpeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option><?php echo e($roomType->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Save</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php elseif(Auth::user()->user_status =='2'): ?>
        <div class="main_container">
            <div class="right_col" role="main">
                <div class="content-sec">
                    <div class="col-md-12">
                        <?php if(session('success')): ?>
                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <ul  class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <i style="float: right;"><a href="<?php echo e(route('roomView')); ?>" style="margin:0; padding:2px;" class="btn btn-success btn-xs" >View All</a></i>
                                    <i style="float: right; margin:0 5px;"><a href="" style="margin:0; padding:2px; background-color: grey; color:#fff;" class="btn btn-xs"  data-toggle="modal" data-target="#room_modal">Add Rooms</a></i>
                                    <i style="float: right; margin:0 5px;"><a href="" style="margin:0; padding:2px;  background-color: grey; color:#fff;" class="btn btn-xs"  data-toggle="modal" data-target="#floor_modal">Add Room Floor</a></i>
                                    <i style="float: right;"><a href="" style="margin:0; padding:2px; background-color: grey; color:#fff;" class="btn btn-xs"  data-toggle="modal" data-target="#roomType_modal">Add Room Type</a></i>

                                    <h2>Room Status</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>

                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 style="text-align: center; color:Green; font-weight: bolder;">Today Room Status
                                            <span style="color:#1ea094;">
                                                    <script type="text/javascript">
                                                        var tmonth=new Array("January","February","March","April","May","June","July","August","September","October","November","December");

                                                        function GetClock(){
                                                            var d=new Date();
                                                            var nmonth=d.getMonth(),ndate=d.getDate(),nyear=d.getFullYear();

                                                            var nhour=d.getHours(),nmin=d.getMinutes(),nsec=d.getSeconds(),ap;

                                                            if(nhour==0){ap=" AM";nhour=12;}
                                                            else if(nhour<12){ap=" AM";}
                                                            else if(nhour==12){ap=" PM";}
                                                            else if(nhour>12){ap=" PM";nhour-=12;}

                                                            if(nmin<=9) nmin="0"+nmin;
                                                            if(nsec<=9) nsec="0"+nsec;

                                                            document.getElementById('clockbox').innerHTML=""+tmonth[nmonth]+" "+ndate+", "+nyear+" "+nhour+":"+nmin+":"+nsec+ap+"";
                                                        }

                                                        window.onload=function(){
                                                            GetClock();
                                                            setInterval(GetClock,1000);
                                                        }
                                                    </script>
                                                    <div id="clockbox"></div>
                                                    </span>
                                        </h5>
                                        <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                            <tr>
                                                <th style="text-align: center; background-color: grey; color:#fff; padding:5px;">Floor</th>
                                                <th style="text-align: center; background-color: grey; color:#fff; padding:5px;" colspan="10">Room</th>
                                            </tr>

                                            <?php $__currentLoopData = $FloorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td style="background-color: #7b4b71; color:#fff; padding:5px;"><?php echo e($floor->name); ?></td>
                                                    <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $RoomTYpeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($floor->id == $room->floor_id && $room->room_type_id == $roomType->id): ?>
                                                                <?php if($room->room_status == 'CheckedOut'): ?>
                                                                    <td>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <a href="<?php echo e(url('admin/'.$room->id.'/RoomStatus')); ?>" style="background-color: Green; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <i style="background-color: grey; color:#fff; padding:5px; font-size: 10px;"><?php echo e($roomType->name); ?></i>
                                                                        </div>
                                                                    </td>
                                                                <?php elseif($room->room_status == 'CheckedIn'): ?>
                                                                    <td>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <a href="" style="background-color: Red; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <i style="background-color: grey; color:#fff; font-size: 10px; padding:5px;"><?php echo e($roomType->name); ?></i>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($room->customer_id == $customerData->id): ?>
                                                                                    <a href="<?php echo e(route('roomCheck')); ?>" style="color:#fff; background-color: Red;  font-size: 10px;" class="btn btn-xs">Sold : <?php echo e($customerData->name); ?></a>
                                                                                <?php endif; ?>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    </td>
                                                                <?php else: ?>
                                                                    <td>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <a href="<?php echo e(url('admin/'.$room->id.'/RoomStatus')); ?>" style="background-color: Orange; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <i style="background-color: grey; color:#fff; padding:5px; font-size: 10px;"><?php echo e($roomType->name); ?></i>
                                                                        </div>
                                                                        <div class="col-sm-12 col-xs-12">
                                                                            <?php $__currentLoopData = $booked; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bookData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($room->id == $bookData->room_id): ?>
                                                                                    <a href="<?php echo e(route('roomBook')); ?>" style="color:#fff; font-size: 10px;" class="btn btn-warning btn-xs">Booked : <?php echo e($bookData->customer_name); ?></a>
                                                                        <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                                    </td>
                                                                <?php endif; ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <hr>
                                        <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                            <tr>
                                                <th style="width:25px; height: 25px; background-color: Orange;"></th>
                                                <th style="color:Orange;">Booked (Pending)</th>
                                                <th style="width:25px; height: 25px; background-color: Red;"></th>
                                                <th style="color:Red;">Checked In (Sold)</th>
                                                <th style="width:25px; height: 25px; background-color: Green;"></th>
                                                <th style="color:Green;">Checked Out (Avialable)</th>
                                            </tr>
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                            
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <div class="x_title">
                                    <h2>Customer Status</h2>
                                    <ul class="nav navbar-right panel_toolbox">
                                        <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                        </li>

                                        <li class="dropdown">
                                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                               aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                            <ul class="dropdown-menu" role="menu">
                                                <li><a href="#">Settings 1</a>
                                                </li>
                                                <li><a href="#">Settings 2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li><a class="close-link"><i class="fa fa-close"></i></a>
                                        </li>
                                    </ul>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="x_content">
                                    <div class="col-md-12 col-sm-12 col-xs-12">
                                        <h5 style="text-align: center; color:Green; font-weight: bolder;">Today Guest Status
                                        </h5>
                                        <table class="table-condensed table-bordered table-hover" style="width: 100%; text-align: center;">
                                            <tr>
                                                <th>Date</th>
                                                <th>Regd No.</th>
                                                <th>Room</th>
                                                <th>Guest Name</th>
                                                <th>Address</th>
                                                <th>Phone</th>
                                                <th>Male</th>
                                                <th>Female</th>
                                                <th>Relation</th>
                                                <th>Entry by</th>
                                                <th>Billing</th>
                                                <th>Action</th>
                                            </tr>
                                            <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomStsCheck): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $roomCheck; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomSts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php if(($roomSts->date === date('Y-m-d')) && $roomStsCheck->date === date('Y-m-d') && $roomStsCheck->id == $roomSts->room_id && $roomStsCheck->room_status == 'CheckedIn' && $roomStsCheck->customer_id == $roomSts->customer_id): ?>
                                                        <tr>
                                                            <td><?php echo e($roomSts->date); ?></td>
                                                            <td>
                                                                <?php echo e($roomSts->customer_id); ?>

                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $RoomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($room->id == $roomSts->room_id): ?>
                                                                        <a href="" style="background-color: Red; color:#fff; padding:5px;"><?php echo e($room->room_no); ?></a>
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                        <?php echo e($customerValue->name); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php $__currentLoopData = $district; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $districtValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($customerValue->district_id == $districtValue->id && $customerValue->id == $roomSts->customer_id): ?>
                                                                            <?php echo e($districtValue->name); ?>

                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($customerValue->id == $roomSts->customer_id): ?>
                                                                        <?php echo e($customerValue->contact_1); ?>

                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td><?php echo e($roomSts->male); ?></td>
                                                            <td><?php echo e($roomSts->female); ?></td>
                                                            <td><?php echo e($roomSts->relation); ?></td>
                                                            <td>
                                                                <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                    <?php if($user->id == $roomSts->user_id): ?>
                                                                        <?php echo e($user->name); ?> (<?php echo e($user->user_type); ?>)
                                                                    <?php endif; ?>
                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                            </td>
                                                            <td>
                                                                <a href="<?php echo e(url('roomCheck/'.$roomSts->id.'/editBill')); ?>" class="btn btn-info btn-xs">View</a>
                                                            </td>
                                                            <td>
                                                                <form action="<?php echo e(url('admin/'.$roomSts->room_id.'/updateRoomSts')); ?>" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                    <input type="hidden" name="room_status" value="CheckedOut">
                                                                    <input type="hidden" name="date" value="">
                                                                    <button type="submit" class="btn btn-success btn-xs">Checked Out</button>
                                                                </form>
                                                                <?php if($roomSts->date == date('Y-m-d')): ?>
                                                                <?php else: ?>
                                                                    <form action="<?php echo e(url('admin/'.$roomSts->room_id.'/updateRoomCheck')); ?>" method="post">
                                                                        <?php echo e(csrf_field()); ?>

                                                                        <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                                                                        <input type="hidden" name="date" value="<?php echo date('Y-m-d') ?>">
                                                                        <input type="hidden" name="room_status" value="CheckedIn">
                                                                        <input type="hidden" name="room_id" value="<?php echo e($roomSts->room_id); ?>">

                                                                        <input type="hidden" name="customer_id" value="<?php echo e($roomSts->customer_id); ?>">
                                                                        <input type="hidden" name="time">
                                                                        <input type="hidden" name="male" value="<?php echo e($roomSts->male); ?>">
                                                                        <input type="hidden" name="female" value="<?php echo e($roomSts->female); ?>">
                                                                        <input type="hidden" name="relation" value="<?php echo e($roomSts->relation); ?>">
                                                                        <input type="hidden" name="purpose" value="<?php echo e($roomSts->purpose); ?>">
                                                                        <input type="hidden" name="remarks" value="<?php echo e($roomSts->remarks); ?>">

                                                                        <button type="submit" class="btn btn-warning btn-xs">Continue</button>
                                                                        <?php endif; ?>
                                                                    </form>
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="room_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="center title_red" id="myModalLabel">Add Room</h4>
                    </div>
                    <?php if(session('success')): ?>
                        <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="modal-body center">
                        <form action="<?php echo e(route('addRoom')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <select class="form-control" id="floor_id" name="floor_id">
                                <option value="">Select Floor</option>
                                <?php $__currentLoopData = $FloorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($floor->id); ?>"><?php echo e($floor->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <input type="number" class="form-control" name="room_no" placeholder="Enter Room No.">
                            <select class="form-control" id="room_type_id" name="room_type_id">
                                <option value="">Select Room Type</option>
                                <?php $__currentLoopData = $RoomTYpeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($roomType->id); ?>"><?php echo e($roomType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="floor_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="center title_red" id="myModalLabel">Add Room Floor</h4>
                    </div>
                    <div class="modal-body center">
                        <form action="<?php echo e(route('addRoomFloor')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="text" class="form-control" name="name" placeholder="Create Floor Name">
                            <select class="form-control">
                                <option value="">Check Floor Exist or Not</option>
                                <?php $__currentLoopData = $FloorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($roomType->id); ?>"><?php echo e($roomType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="modal fade" id="roomType_modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog modal-sm" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        <h4 class="center title_red" id="myModalLabel">Add Room Type</h4>
                    </div>
                    <?php if(session('success')): ?>
                        <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="modal-body center">
                        <form action="<?php echo e(route('addRoomType')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="text" class="form-control" name="name" placeholder="Create Room Type">
                            <select class="form-control">
                                <option value="">Check Exist Room Type or Not</option>
                                <?php $__currentLoopData = $RoomTYpeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option><?php echo e($roomType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Save</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <div class="main_container">
            <div class="" role="main">
                <div class="">
                    <div class="col-md-12">
                        <?php if(session('success')): ?>
                            <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                        <?php endif; ?>
                        <?php if($errors->any()): ?>
                            <ul  class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        <?php endif; ?>
                        <div class="col-md-12 col-sm-12 col-xs-12">
                            <div class="x_panel">
                                <a class="btn btn-danger btn-xs">Your Account Was Suspended ! Please Contact Hotel Sahara Inn, Macchapokhari</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>