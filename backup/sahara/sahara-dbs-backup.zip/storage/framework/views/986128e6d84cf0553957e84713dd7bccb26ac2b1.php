

<?php $__env->startSection('content'); ?>

    <div class="main_container">
        <div class="right_col" role="main">
            <div class="content-sec">
                <div class="col-md-12">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Room CheckedIn Form</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content" style="text-align: center;">
                                <form action="<?php echo e(url('admin/'.$roomDefaultData->id.'/updateRoomCheck')); ?>" data-parsley-validate method="post"
                                      enctype="multipart/form-data" class="form-horizontal form-label-left">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="customer_name">Customer Name</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <select name="customer_id" id="customer_id" class="form-control input-sm" required="required">
                                            <option value="">[Select Customer]</option>
                                            <?php $__currentLoopData = $CustomeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($customer->id); ?>"><?php echo e($customer->name); ?> (<?php echo e($customer->customer_id_no); ?>)</option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <select name="room_id" id="room_id" class="form-control input-sm" required="required">
                                            <option value="<?php echo e($roomDefaultData->id); ?>">Room No.: <?php echo e($roomDefaultData->room_no); ?></option>
                                        </select>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="number" name="male" class="form-control input-sm" placeholder="No. of Male">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="number" class="form-control input-sm" name="female" placeholder="No. of Female">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" class="form-control input-sm" name="relation" placeholder="Relaion">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" class="form-control input-sm" name="purpose" placeholder="Purpose Of Visit">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Checked in Date</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="date" class="form-control input-sm" required="required" name="date" value="<?php echo date('Y-m-d') ?>">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Arrival Time</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="time" class="form-control input-sm" required="required" name="time">
                                        <i>hr:min:AM/PM</i>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        
                                        <select name="room_status" id="room_status" class="form-control input-sm" required="required">
                                            <option value="">[Select Action]</option>
                                            <option value="CheckedIn">Checked In</option>
                                        </select>
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Room Rate</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" name="total_transaction" class="form-control input-sm">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Paid Amount</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" name="guest_paid" class="form-control input-sm">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Remarks</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" name="remarks" class="form-control input-sm">
                                    </div>
                                    <div class="clearfix"></div>
                                    <div style="width:100px; margin:10px auto;">
                                        <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Done</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Room Booking</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content" style="text-align: center;">
                                <form action="" data-parsley-validate method="post"
                                      enctype="multipart/form-data" class="form-horizontal form-label-left">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">

                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="customer_name">Customer Name</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" class="form-control" name="customer_name" placeholder="Insert Name">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <select name="room_id" id="room_id" class="form-control">
                                            <option value="<?php echo e($roomDefaultData->id); ?>">Room No.: <?php echo e($roomDefaultData->room_no); ?></option>
                                        </select>
                                    </div>
                                    <input type="hidden" name="room_status" value="Booked">
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="phone">Contact</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" class="form-control" name="phone" placeholder="Mobile Number">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="text" class="form-control"  placeholder="Mobile Number">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="people">No. of People</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="number" class="form-control" name="people" placeholder="No. of People">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Booking Date</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="date" class="form-control" name="date" value="<?php echo date('Y-m-d') ?>">
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <label for="">Arrival Time</label>
                                    </div>
                                    <div class="col-md-2 col-sm-2 col-xs-12" style="margin:5px 0;">
                                        <input type="time" class="form-control" name="time">
                                        <i>hr:min:AM/PM</i>
                                    </div>

                                    <div class="clearfix"></div>
                                    <div style="width:100px; margin:10px auto;">
                                        <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Book</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>