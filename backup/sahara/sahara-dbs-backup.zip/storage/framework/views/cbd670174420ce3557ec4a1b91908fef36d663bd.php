<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="shortcut icon" href="<?php echo e(url('public/icon.png')); ?>">
    <title>Hotel Guest Management Software Control</title>
    <link rel="stylesheet" href="<?php echo e(url('public/bootstrap/css/bootstrap.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/bootstrap/css/font-awesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/bootstrap/css/nprogress.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/bootstrap/css/prettify.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(url('public/bootstrap/css/custom.min.css')); ?>">
</head>
<body style="background-image: url(<?php echo e(url('public/images/hotelsaharainn.png')); ?>); background-color: #fff;">
<div class="container">
    <div style="width:200px; margin:100px auto; text-align: center; ">
        <section class="login_content">
            <?php if(session('error')): ?>
                <span class="alert alert-danger"> <?php echo e(session('error')); ?></span>
            <?php endif; ?>
            <?php if(session('success')): ?>
                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
            <?php endif; ?>
        <h4 style="background-color: #757575; color:#fff; padding:8px; margin-top: 20px;">Validataion Create</h4>
                <form action="" data-parsley-validate method="post"
                      enctype="multipart/form-data" class="form-horizontal form-label-left">

                    <?php echo e(csrf_field()); ?>

                        <input type="date" class="form-control" name="name">
            <div style="margin:20px;"></div>
            <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Generate</button>
        </form>
        </section>
        <section class="login_content">
            <h4 style="background-color: #757575; color:#fff; padding:8px; margin-top: 20px;">Validataion Code</h4>
            <?php $__currentLoopData = $codeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($code->name); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </section>
    </div>
</div>
</body>
</html>