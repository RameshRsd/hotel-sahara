<?php $__env->startSection('content'); ?>

    <div class="main_container">
        <div class="right_col" role="main">
            <div class="content-sec">
                <div class="col-md-12">
                    <?php if(session('success')): ?>
                        <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Customer Status</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <div class="col-md-12 col-sm-12 col-xs-12">

                                    <div class="col-sm-7 col-md-7 col-xs-12">
                                                                    <form action="<?php echo e(url('roomCheck/'.$roomData->id.'/updateBill')); ?>" method="post">
                                                                        <?php echo e(csrf_field()); ?>

                                                                        <h5>Transaction Date: <?php echo e($roomData->date); ?></h5>
                                                                        <label for="">Total Transaction</label>
                                                                        <input type="text" class="form-control" name="total_transaction" value="<?php echo e($roomData->total_transaction); ?>" placeholder="Total Bill">
                                                                        <div style="margin:10px 0;"></div>
                                                                        <label for="">Paid</label>
                                                                        <input type="text" class="form-control" name="guest_paid" value="<?php echo e($roomData->guest_paid); ?>" placeholder="Paid">
                                                                        <label for="">Discount</label>
                                                                        <input type="text" class="form-control" name="guest_discount" value="<?php echo e($roomData->guest_discount); ?>" placeholder="Discount">
                                                                        <div style="margin:10px 0;"></div>
                                                                        <label for="">Due (Total Due :
                                                                        <?php $__currentLoopData = $guestData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php if($guest->customer_id == $roomData->customer_id): ?>
                                                                                    <?php if(!$roomData->customer_id): ?>
                                                                                        <?php else: ?>
                                                                                     <?php echo e($guest->guest_due); ?>+                                                                                        <?php endif; ?>
                                                                                    <?php endif; ?>
                                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        ) // Previous Due + Current Due</label>
                                                                        <input type="text" class="form-control" name="guest_due" value="<?php echo e($roomData->guest_due); ?>" placeholder="Due">
                                                                        <div style="margin:10px 0;"></div>
                                                                        <label for="">Remarks</label>
                                                                        <input type="text" class="form-control" name="remarks" value="<?php echo e($roomData->remarks); ?>">
                                                                        <div style="margin:10px 0;"></div>
                                                                        <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff;">Update</button>
                                                                    </form>
                                                                </div>
                                    <div class="col-sm-5 col-md-5 col-xs-12" style=" text-align: center;">
                                                                    <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customerValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                        <?php if($customerValue->id == $roomData->customer_id): ?>
                                                                            <img src="<?php echo e(url('public/images/Customer/'.$customerValue->photo)); ?>" alt="image not found" width="100">
                                                                            <br><br><b><?php echo e($customerValue->name); ?></b><br>(<i><?php echo e($customerValue->contact_1); ?></i>)
                                                                            <br>
                                                                                <?php $__currentLoopData = $locationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($location->id == $customerValue->location_id): ?>
                                                                                        <?php echo e($location->name); ?>-<?php echo e($customerValue->ward_no); ?>, <?php echo e($customerValue->tole); ?><br>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php $__currentLoopData = $districtData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($district->id == $customerValue->district_id): ?>
                                                                                        <?php echo e($district->name); ?>,
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php $__currentLoopData = $zoneData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($zone->id == $customerValue->zone_id): ?>
                                                                                        <?php echo e($zone->name); ?> Zone<br>
                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                                <?php $__currentLoopData = $countryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                    <?php if($country->id == $customerValue->country_id): ?>
                                                                                        <?php echo e($country->country_name); ?>

                                                                                    <?php endif; ?>
                                                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <br>

                                                                            <i><?php echo e($customerValue->id_type); ?> (ID No.): <?php echo e($customerValue->customer_id_no); ?></i>
                                                                        <?php endif; ?>
                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                </div>
                                    <div class="clear"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>