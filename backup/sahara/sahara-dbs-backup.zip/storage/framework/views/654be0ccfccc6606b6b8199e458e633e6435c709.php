

<?php $__env->startSection('content'); ?>

    <div class="main_container">
        <div class="right_col" role="main">
            <div class="content-sec">
                <div class="col-md-12">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <?php if(session('success')): ?>
                                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <ul  class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <div class="x_title">
                                <h2>Room Book Record</h2>
                                <i style="float: right;"><a href="<?php echo e(route('viewCustomer')); ?>" style="margin:0; padding:2px;" class="btn btn-success btn-xs">View Customer</a></i>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content" style="text-align: center;">


                                <table class="table-condensed table-bordered table-hover" style="width: 100%;">
                                    Total : <i style="color:Green; font-weight: bolder;"><?php echo e(count($roomData)); ?></i> Record Found !
                                    <tr>
                                        <th>SN</th>
                                        <th>Name</th>
                                        <th>Contact</th>
                                        <th>Date</th>
                                        <th>No. of People</th>
                                        <th>Arrival time</th>
                                        <th>Booked Room</th>
                                        <th>Enter by</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php if(count($roomData)>0): ?>
                                        <?php $__currentLoopData = $roomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($room->customer_name); ?></td>
                                                <td><?php echo e($room->phone); ?></td>
                                                <td><?php echo e($room->date); ?></td>
                                                <td><?php echo e($room->people); ?></td>
                                                <td><?php echo e($room->time); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $bookData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($value->id == $room->room_id && $value->room_status == 'Booked'): ?>
                                                        <a style="background-color: Orange; color:#fff; padding:5px;"><?php echo e($value->room_no); ?> <i>(Still Booked)</i></a>
                                                            <?php endif; ?>
                                                        <?php if($value->id == $room->room_id && $value->room_status == 'CheckedIn'): ?>
                                                        <a style="background-color: Red; color:#fff; padding:5px;"><?php echo e($value->room_no); ?> <i>(Checked In)</i></a>
                                                            <?php endif; ?>
                                                        <?php if($value->id == $room->room_id && $value->room_status == 'CheckedOut'): ?>
                                                        <a style="background-color: Green; color:#fff; padding:5px;"><?php echo e($value->room_no); ?> <i>(Room Left)</i></a>
                                                            <?php endif; ?>

                                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($user->id == $room->user_id): ?>
                                                            <?php echo e($user->name); ?> (<?php echo e($user->user_type); ?>)
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td style="padding:0;">
                                                    <?php $__currentLoopData = $bookData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($value->id == $room->room_id && $value->room_status == 'Booked'): ?>
                                                            <form action="<?php echo e(url('roomBook/delete/'.$room->room_id)); ?>" method="post">
                                                                <?php echo e(csrf_field()); ?>

                                                                <input type="hidden" name="room_status" value="CheckedOut">
                                                                <input type="hidden" name="date" value="">
                                                                <button type="submit" onclick="return confirm('Are you sure you want to Unbook this room?');" class="btn btn-danger btn-xs">UnBook</button>
                                                            </form>
                                                            <?php elseif($value->id == $room->room_id && $value->room_status == 'CheckedOut'): ?>
                                                            <form action="<?php echo e(url('roomBook/delete/'.$room->room_id)); ?>" method="post">
                                                                <?php echo e(csrf_field()); ?>

                                                                <input type="hidden" name="room_status" value="Booked">
                                                                <input type="hidden" name="date" value="">
                                                                <button type="submit" onclick="return confirm('Are you sure you want to Book this room?');" class="btn btn-success btn-xs">Book</button>
                                                            </form>
                                                            <a href="<?php echo e(url('roomBook/deleteItm/'.$room->id)); ?>" class="btn btn-danger btn-xs">Delete</a>
                                                        <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="9">Record Not Found</td>
                                        </tr>
                                    <?php endif; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>