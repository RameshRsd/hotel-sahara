<?php $__env->startSection('aside'); ?>
    <div class="col-md-3 left_col">
        <?php $__currentLoopData = $server; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $codeData): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($codeData->name < date('Y-m-d')): ?>
             <?php else: ?>
                <?php if(Auth::user()->user_status =='1'): ?>
                <div class="left_col scroll-view">
                    <!-- sidebar menu -->
                    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                        <div class="menu_section">
                            <ul class="nav side-menu">
                                    <li><a href="<?php echo e(route('admin')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                                    </li>
                                    <?php if(\Illuminate\Support\Facades\Auth::user()->user_type =='admin' || Auth::user()->user_status =='2'): ?>
                                    <li><a href="<?php echo e(route('addUser')); ?>"><i class="fa fa-user"></i> Users</a></li>
                                    <li><a><i class="fa fa-user"></i> Customer Entry <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?php echo e(route('addCustomer')); ?>">Add Customer</a>
                                            </li>
                                            <li><a href="<?php echo e(route('viewCustomer')); ?>">View Customer</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo e(route('roomBook')); ?>"><i class="fa fa-user"></i> Room Book</a></li>
                                    <li><a href="<?php echo e(route('roomCheck')); ?>"><i class="fa fa-user"></i> Room Check In</a></li>
                                    <?php if(Auth::user()->user_type =='ramesh'): ?>
                                    <li><a href="<?php echo e(route('addValidation')); ?>"><i class="fa fa-user"></i> Server Control</a></li>
                                        <?php endif; ?>
                                    <?php else: ?>
                                    <li><a><i class="fa fa-user"></i> Customer Entry <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?php echo e(route('addCustomer')); ?>">Add Customer</a>
                                            </li>
                                            <li><a href="<?php echo e(route('viewCustomer')); ?>">View Customer</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo e(route('roomBook')); ?>"><i class="fa fa-user"></i> Room Book</a></li>
                                    <li><a href="<?php echo e(route('roomCheck')); ?>"><i class="fa fa-user"></i> Room Check In</a></li>

                                    <?php endif; ?>
                                </ul>
                        </div>
                        <div class="menu_section">

                        </div>

                    </div>
                    <!-- /sidebar menu -->

                    <!-- /menu footer buttons -->
                    <div class="sidebar-footer hidden-small">
                        <a data-toggle="tooltip" data-placement="top" title="Settings">
                            <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                            <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="Lock">
                            <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo e(route('logout')); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                        </a>
                    </div>
                    <!-- /menu footer buttons -->
                </div>
                <?php else: ?>
                <?php endif; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php if(Auth::user()->user_status =='2'): ?>
                <div class="left_col scroll-view">
                    <!-- sidebar menu -->
                    <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
                        <div class="menu_section">
                            <ul class="nav side-menu">
                                <li><a href="<?php echo e(route('admin')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                                </li>
                                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type =='admin' || Auth::user()->user_status =='2'): ?>
                                    <li><a href="<?php echo e(route('addUser')); ?>"><i class="fa fa-user"></i> Users</a></li>
                                    <li><a><i class="fa fa-user"></i> Customer Entry <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?php echo e(route('addCustomer')); ?>">Add Customer</a>
                                            </li>
                                            <li><a href="<?php echo e(route('viewCustomer')); ?>">View Customer</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo e(route('roomBook')); ?>"><i class="fa fa-user"></i> Room Book</a></li>
                                    <li><a href="<?php echo e(route('roomCheck')); ?>"><i class="fa fa-user"></i> Room Check In</a></li>
                                    <?php if(Auth::user()->user_type =='ramesh'): ?>
                                        <li><a href="<?php echo e(route('addValidation')); ?>"><i class="fa fa-user"></i> Server Control</a></li>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <li><a><i class="fa fa-user"></i> Customer Entry <span class="fa fa-chevron-down"></span></a>
                                        <ul class="nav child_menu">
                                            <li><a href="<?php echo e(route('addCustomer')); ?>">Add Customer</a>
                                            </li>
                                            <li><a href="<?php echo e(route('viewCustomer')); ?>">View Customer</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a href="<?php echo e(route('roomBook')); ?>"><i class="fa fa-user"></i> Room Book</a></li>
                                    <li><a href="<?php echo e(route('roomCheck')); ?>"><i class="fa fa-user"></i> Room Check In</a></li>

                                <?php endif; ?>
                            </ul>
                        </div>
                        <div class="menu_section">

                        </div>

                    </div>
                    <!-- /sidebar menu -->

                    <!-- /menu footer buttons -->
                    <div class="sidebar-footer hidden-small">
                        <a data-toggle="tooltip" data-placement="top" title="Settings">
                            <span class="glyphicon glyphicon-cog" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="FullScreen">
                            <span class="glyphicon glyphicon-fullscreen" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="Lock">
                            <span class="glyphicon glyphicon-eye-close" aria-hidden="true"></span>
                        </a>
                        <a data-toggle="tooltip" data-placement="top" title="Logout" href="<?php echo e(route('logout')); ?>">
                            <span class="glyphicon glyphicon-off" aria-hidden="true"></span>
                        </a>
                    </div>
                    <!-- /menu footer buttons -->
                </div>
         <?php endif; ?>

    </div>
<?php $__env->stopSection(); ?>