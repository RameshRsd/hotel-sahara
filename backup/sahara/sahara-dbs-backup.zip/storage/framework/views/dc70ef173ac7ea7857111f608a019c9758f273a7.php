<?php $__env->startSection('content'); ?>

    <div class="main_container">
        <div class="right_col" role="main">
            <div class="content-sec">
                <div class="col-md-12">
                    <?php if(session('success')): ?>
                        <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <ul  class="alert alert-danger">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    <?php endif; ?>
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Room list</h2>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <div class="col-md-12 col-sm-12 col-xs-12">
                                    <table class="table-condensed table-bordered table-hover" style="width: 100%;">
                                        <tr>
                                            <th>SN</th>
                                            <th>Room No.</th>
                                            <th>Room Type</th>
                                            <th>Room Floor</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php $__currentLoopData = $roomData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$roomSts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($roomSts->room_no); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $roomTypeData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $roomType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($roomType->id == $roomSts->room_type_id): ?>
                                                            <?php echo e($roomType->name); ?>

                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $floorData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $floor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($floor->id == $roomSts->floor_id): ?>
                                                            <?php echo e($floor->name); ?>

                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>

                                                    <?php if(\Illuminate\Support\Facades\Auth::user()->user_type =='admin'): ?>
                                                        <a href="<?php echo e(url('roomView/'.$roomSts->id.'/editRoom')); ?>" class="btn btn-primary btn-xs">Edit</a>
                                                        <a href="<?php echo e(url('roomView/delete/'.$roomSts->id)); ?>" onclick="return confirm('Are you sure you want to delete this Record?');"  class="btn btn-danger btn-xs">Delete</a>
                                                    <?php else: ?>
                                                        <a class="btn btn-primary btn-xs" disabled="disabled">Edit</a>
                                                        <a disabled="disabled" class="btn btn-danger btn-xs">Delete</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>