<?php $__env->startSection('top'); ?>
<div class="top_nav col-sm-12 col-xs-12"style="background-color: #808080; position: fixed; z-index: 111111;">
    <div id="sidebar-menu" class="col-sm-9 col-xs-12">
        <div class="menu_section" style="margin-bottom: 0;">
            <ul class="nav side-menu">
                <li><a href="<?php echo e(route('admin')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                </li>
                <?php if(\Illuminate\Support\Facades\Auth::user()->user_type =='admin' || Auth::user()->user_status =='2'): ?>
                    <li><a href="<?php echo e(route('addUser')); ?>"><i class="fa fa-user"></i> Users</a></li>
                    
                        
                            
                            
                            
                            
                        
                    
                    <li><a href="<?php echo e(route('addCustomer')); ?>"><i class="fa fa-user"></i> Customer Entry</a></li>
                    <li><a href="<?php echo e(route('viewCustomer')); ?>"><i class="fa fa-user"></i> Customer Details</a></li>
                    <li><a href="<?php echo e(route('roomBook')); ?>"><i class="fa fa-user"></i> Room Book</a></li>
                    <li><a href="<?php echo e(route('roomCheck')); ?>"><i class="fa fa-user"></i> Room Check In</a></li>
                    <?php if(Auth::user()->user_type =='ramesh'): ?>
                        <li><a href="<?php echo e(route('addValidation')); ?>"><i class="fa fa-user"></i> Server Control</a></li>
                    <?php endif; ?>
                <?php else: ?>
                    
                        
                            
                            
                            
                            
                        
                    
                    <li><a href="<?php echo e(route('addCustomer')); ?>"><i class="fa fa-user"></i> Customer Entry</a></li>
                    <li><a href="<?php echo e(route('viewCustomer')); ?>"><i class="fa fa-user"></i> Customer Details</a></li>
                    <li><a href="<?php echo e(route('roomBook')); ?>"><i class="fa fa-user"></i> Room Book</a></li>
                    <li><a href="<?php echo e(route('roomCheck')); ?>"><i class="fa fa-user"></i> Room Check In</a></li>

                <?php endif; ?>
            </ul>
        </div>
    </div>
    <div class="col-sm-3 col-xs-12">
        <nav>
            
                
            
            <ul class="nav navbar-nav navbar-right">
                <li class="">
                    <a href="" class="user-profile dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                        <span class=" fa fa-angle-down"></span>
                    </a>
                    <ul class="dropdown-menu dropdown-usermenu pull-right" style="color:#2cd2e4;">
                        <li><a href=""  style="color:#2cd2e4;"><?php echo e(Auth::user()->name); ?> (<?php echo e((Auth::user()->user_type)); ?>)</a></li>
                        
                        <li><a href="<?php echo e(route('logout')); ?>"  style="color:#2cd2e4;"><i class="fa fa-sign-out pull-right"></i> Log Out</a></li>
                    </ul>
                </li>
                <li>
                    <img src="<?php echo e(url('public/images/userimages/'.Auth::user()->image)); ?>" class="img-responsive" style="border-radius: 45%; border:1px  solid #808080; background-color: #fff;" alt="" width="60">
                </li>
            </ul>
        </nav>
    </div>
</div>

    <?php $__env->stopSection(); ?>