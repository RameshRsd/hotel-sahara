

<?php $__env->startSection('content'); ?>

    <div class="main_container">
        <div class="right_col" role="main">
            <div class="content-sec">
                <div class="col-md-12">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <?php if(session('success')): ?>
                                <span class="alert alert-success"> <?php echo e(session('success')); ?></span>
                            <?php endif; ?>
                            <?php if($errors->any()): ?>
                                <ul  class="alert alert-danger">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            <?php endif; ?>
                            <div class="x_title">
                                <h2>Customer Record</h2>
                                <i style="float: right;"><a href="<?php echo e(route('addCustomer')); ?>" style="margin:0; padding:2px;" class="btn btn-success btn-xs">Add Customer</a></i>
                                <ul class="nav navbar-right panel_toolbox">
                                    <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                                    </li>

                                    <li class="dropdown">
                                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button"
                                           aria-expanded="false"><i class="fa fa-wrench"></i></a>
                                        <ul class="dropdown-menu" role="menu">
                                            <li><a href="#">Settings 1</a>
                                            </li>
                                            <li><a href="#">Settings 2</a>
                                            </li>
                                        </ul>
                                    </li>
                                    <li><a class="close-link"><i class="fa fa-close"></i></a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                            <div class="x_content">
                                <form action="" method="post">
                                    <?php echo e(csrf_field()); ?>

                                    <div class="col-sm-2">
                                        <input type="text" name="name" class="form-control input-sm" placeholder="Search by Name">
                                    </div>
                                    <div class="clearfix"></div>
                                    <div class="col-sm-2">
                                        <input type="text" name="id_no" class="form-control input-sm" placeholder="Search by ID">
                                    </div>
                                        <div class="clearfix"></div>
                                    <div class="col-sm-2">
                                        <input type="text" name="contact_1" class="form-control input-sm" placeholder="Search by Phone">
                                    </div>
                                            <div class="clearfix"></div>
                                    <div class="col-sm-2">
                                        <button type="submit" class="btn btn-default" style="background-color: #757575; color:#fff; width: 100%;">Search</button>
                                    </div>
                                </form>
                            </div>
                            <div class="x_content" style="text-align: center;">
                                Total : <i style="color:Green; font-weight: bolder;"><?php echo e(count($customerData)); ?></i> Record Found !
                                <table class="table-condensed table-bordered table-hover" style="width: 100%;">
                                    <tr>
                                        <th>SN</th>
                                        <th>Name</th>
                                        <th>Nationality</th>
                                        <th>Address</th>
                                        <th>ID no.</th>
                                        <th>Contact</th>
                                        <th>Photo</th>
                                        <th>Document</th>
                                        <th>Enter BY</th>
                                        <th>Social Link</th>
                                        <th>Action</th>
                                    </tr>
                                    <?php if(count($customerData)>0): ?>
                                        <?php $__currentLoopData = $customerData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e(++$key); ?></td>
                                                <td><?php echo e($customer->name); ?></td>
                                                <td><?php echo e($customer->nationality); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $locationData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($location->id == $customer->location_id): ?>
                                                            <?php echo e($location->name); ?>-<?php echo e($customer->ward_no); ?>, <?php echo e($customer->tole); ?><br>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $districtData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $district): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($district->id == $customer->district_id): ?>
                                                                <?php echo e($district->name); ?>,
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php $__currentLoopData = $zoneData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($zone->id == $customer->zone_id): ?>
                                                                <?php echo e($zone->name); ?> Zone<br>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $countryData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($country->id == $customer->country_id): ?>
                                                            <?php echo e($country->country_name); ?>

                                                                <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><?php echo e($customer->customer_id_no); ?><br>(<?php echo e($customer->id_type); ?>)</td>
                                                <td><?php echo e($customer->contact_1); ?><br><?php echo e($customer->contact_2); ?><br><?php echo e($customer->contact_3); ?></td>
                                                <td><a href="<?php echo e(url('public/images/Customer/'.$customer->photo)); ?>" target="_blank"><img src="<?php echo e(url('public/images/Customer/'.$customer->photo)); ?>" alt="image not found" width="50"></a></td>
                                                <td><a href="<?php echo e(url('public/images/Customer/'.$customer->customer_doc)); ?>" target="_blank">Open</a></td>
                                                <td>
                                                    <?php $__currentLoopData = $userData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($user->id == $customer->user_id): ?>
                                                            <?php echo e($user->name); ?> (<?php echo e($user->user_type); ?>)
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td><a href="<?php echo e($customer->fb_link); ?>" target="_blank"><?php echo e($customer->fb_link); ?></a></td>
                                                <td style="padding:0;">
                                                    <?php if(\Illuminate\Support\Facades\Auth::user()->user_type =='admin'): ?>
                                                    <a href="<?php echo e(url('viewCustomer/'.$customer->id.'/editCustomer')); ?>" class="btn btn-primary btn-xs">View</a>
                                                    <a href="<?php echo e(url('viewCustomer/delete/'.$customer->id)); ?>" onclick="return confirm('Are you sure you want to delete this Record?');" class="btn btn-danger btn-xs">delete</a>
                                                <?php else: ?>
                                                        <a class="btn btn-primary btn-xs" disabled="disabled">View</a>
                                                        <a disabled="disabled" class="btn btn-danger btn-xs">delete</a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                        <tr>
                                            <td colspan="11">Record Not Found</td>
                                        </tr>
                                     <?php endif; ?>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make($masterPath.'.master.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>