<?php $__env->startSection('footer'); ?>
    <footer>
        <div class="pull-right">
            Design by <a href="http://geniusservicenepal.com/" target="_blank" style="color:Blue;">Genius Service Nepal Pvt. Ltd</a>
        </div>
        <div class="clearfix"></div>
    </footer>
    </div>
    </div>





    <script src="<?php echo e(url('public/bootstrap/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/fastclick.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/nprogress.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/bootstrap-wysiwyg.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/jquery.hotkeys.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/prettify.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/jquery.hotkeys.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/custom.min.js')); ?>"></script>
    <script src="<?php echo e(url('public/bootstrap/js/custom.js')); ?>"></script>
</body>
</html>

<?php $__env->stopSection(); ?>