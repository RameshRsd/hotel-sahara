@include($masterPath.'.layouts.header')
@include($masterPath.'.layouts.subFooter')

@yield('header')

@yield('content')

@yield('subFooter')

